import java.awt.Color;
import java.awt.*;
import javax.swing.*;

/**
 *
 * @author DENISE NEVES
 */
public class NFrame extends JFrame{
   public NFrame(){ 
    Color cor = new Color(210,56,255);
    
    Container c = getContentPane();
    setLocation(10,0);
    setTitle("Aplicação Operadoras/Planos");
    setSize(1000,600);
    setUndecorated(true);
    c.setBackground (cor);
    getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
    getRootPane().setBorder(BorderFactory.createLineBorder(Color.black,3));
    setDefaultCloseOperation(EXIT_ON_CLOSE);
   }
   public static void main(String arg[]){
   new NFrame().show();
   }
}